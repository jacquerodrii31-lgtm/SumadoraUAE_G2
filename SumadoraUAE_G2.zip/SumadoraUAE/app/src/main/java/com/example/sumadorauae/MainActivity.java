package com.example.sumadorauae; // Define el paquete al cual pertenece esta clase principal

import android.os.Bundle; // Importa la clase Bundle para manejar estados de la actividad
import android.util.Log; // Importa la clase Log para registrar mensajes de depuración en Logcat
import android.view.View; // Importa la clase View para manejar eventos de interfaz de usuario
import android.widget.Button; // Importa la clase Button para interactuar con botones
import android.widget.EditText; // Importa la clase EditText para manejar campos de entrada de texto
import android.widget.TextView; // Importa la clase TextView para mostrar texto en pantalla
import android.widget.Toast; // Importa la clase Toast para mostrar mensajes flotantes breves
import androidx.appcompat.app.AppCompatActivity; // Importa AppCompatActivity para compatibilidad con actividades modernas

public class MainActivity extends AppCompatActivity { // Declara la clase pública MainActivity que hereda de AppCompatActivity

    private EditText etNumero1; // Declara el atributo privado para el primer campo de texto numérico
    private EditText etNumero2; // Declara el atributo privado para el segundo campo de texto numérico
    private Button btnSumar; // Declara el atributo privado para el botón de sumar
    private TextView tvResultado; // Declara el atributo privado para la etiqueta de resultado
    private static final String TAG = "APP"; // Declara una constante TAG para los registros en Logcat

    @Override // Anotación que indica la sobrescritura del método onCreate original
    protected void onCreate(Bundle savedInstanceState) { // Método principal de ciclo de vida que se ejecuta al iniciar la actividad
        super.onCreate(savedInstanceState); // Llama al método onCreate de la clase superclase
        setContentView(R.layout.activity_main); // Asocia el archivo de diseño XML activity_main con esta actividad

        etNumero1 = findViewById(R.id.etNumero1); // Vincula la variable local con el EditText del XML usando su ID[cite: 1]
        etNumero2 = findViewById(R.id.etNumero2); // Vincula la variable local con el segundo EditText del XML usando su ID[cite: 1]
        btnSumar = findViewById(R.id.btnSumar); // Vincula la variable local con el Button del XML usando su ID[cite: 1]
        tvResultado = findViewById(R.id.tvResultado); // Vincula la variable local con el TextView del XML usando su ID[cite: 1]

        btnSumar.setOnClickListener(new View.OnClickListener() { // Registra un escuchador de eventos de clic para el botón[cite: 1]
            @Override // Anotación para indicar la sobrescritura del método onClick
            public void onClick(View v) { // Método que se ejecuta cuando el usuario hace clic en el botón
                Log.d(TAG, "sumar() inicio"); // Registra un mensaje de depuración al iniciar la operación de suma[cite: 1]

                String texto1 = etNumero1.getText().toString().trim(); // Lee el texto del primer campo, lo convierte a String y elimina espacios[cite: 1]
                String texto2 = etNumero2.getText().toString().trim(); // Lee el texto del segundo campo, lo convierte a String y elimina espacios[cite: 1]

                if (texto1.isEmpty()) { // Valida si el primer campo de texto está vacío[cite: 1]
                    etNumero1.setError("Ingrese un número válido"); // Muestra un mensaje de error flotante en el primer EditText[cite: 1]
                    Log.d(TAG, "Error: el primer campo está vacío"); // Registra en Logcat que el primer campo estaba vacío
                    return; // Detiene la ejecución del método si hay error
                }

                if (texto2.isEmpty()) { // Valida si el segundo campo de texto está vacío[cite: 1]
                    etNumero2.setError("Ingrese un número válido"); // Muestra un mensaje de error flotante en el segundo EditText[cite: 1]
                    Log.d(TAG, "Error: el segundo campo está vacío"); // Registra en Logcat que el segundo campo estaba vacío
                    return; // Detiene la ejecución del método si hay error
                }

                try { // Bloque try para intentar realizar conversiones y operaciones numéricas
                    int n1 = Integer.parseInt(texto1); // Convierte la cadena del primer campo en un número entero[cite: 1]
                    int n2 = Integer.parseInt(texto2); // Convierte la cadena del segundo campo en un número entero[cite: 1]

                    Log.d(TAG, "$n1=" + n1 + "$"); // Registra el valor del primer número convertido en Logcat[cite: 1]
                    Log.d(TAG, "$n2=" + n2 + "$"); // Registra el valor del segundo número convertido en Logcat[cite: 1]

                    int suma = n1 + n2; // Realiza la suma aritmética de ambos números enteros[cite: 1]
                    Log.d(TAG, "resultado =" + suma); // Registra el resultado numérico de la suma en Logcat[cite: 1]

                    tvResultado.setText("Resultado: " + suma); // Muestra el texto formateado con el resultado en el TextView[cite: 1]

                    Toast.makeText(MainActivity.this, "Suma realizada con éxito", Toast.LENGTH_SHORT).show(); // Muestra un Toast de confirmación al usuario[cite: 1]

                } catch (NumberFormatException e) { // Captura la excepción en caso de que ocurra un error de formato numérico[cite: 1]
                    Log.d(TAG, "Error de formato numérico: " + e.getMessage()); // Registra el error de formato en Logcat
                    Toast.makeText(MainActivity.this, "Por favor, ingrese números válidos", Toast.LENGTH_SHORT).show(); // Muestra un Toast advirtiendo el error
                } // Fin del bloque try-catch
            } // Fin del método onClick
        }); // Fin del registro del escuchador de clics del botón
    } // Fin del método onCreate
} // Fin de la clase MainActivity